#define FILE_IN_HOME_DIR "../../jmpacheco"
//#define FILE_IN_HOME_DIR "/home/anderson/.bashrc"
#define QUEUE_NUMBER 0xff
